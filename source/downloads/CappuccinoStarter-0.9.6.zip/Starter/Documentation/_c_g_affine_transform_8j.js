var _c_g_affine_transform_8j =
[
    [ "CGAffineTransformInvert", "_c_g_affine_transform_8j.html#a7fbeeee49fbad301876a71a146f7995a", null ],
    [ "CGAffineTransformMakeRotation", "_c_g_affine_transform_8j.html#ad2a46b999df28a4cabc4fd59c5a083a9", null ],
    [ "CGAffineTransformRotate", "_c_g_affine_transform_8j.html#a49a88e45ec9dfbb6761a0c25c5fda7b7", null ],
    [ "CGRectApplyAffineTransform", "_c_g_affine_transform_8j.html#aa2cac55239f169c578848a871f67fcb2", null ],
    [ "CPStringFromCGAffineTransform", "_c_g_affine_transform_8j.html#ab073ac1dea17b0d2fcaf32b7cd3a26c8", null ],
    [ "tx", "_c_g_affine_transform_8j.html#a0512a7cb9d104ee603db0949d6042413", null ]
];