var _c_g_gradient_8j =
[
    [ "CGGradientCreateWithColorComponents", "_c_g_gradient_8j.html#ad8d31cbcc471f671205098ba416bfc84", null ],
    [ "CGGradientCreateWithColors", "_c_g_gradient_8j.html#a71e1057637ad447b0d22248d684b8125", null ],
    [ "CGGradientRelease", "_c_g_gradient_8j.html#a4b46e11178bb85afa5b7c1e7bc876f4d", null ],
    [ "CGGradientRetain", "_c_g_gradient_8j.html#a4633a3faa30682de4d166e2426369c2e", null ],
    [ "kCGGradientDrawsAfterEndLocation", "_c_g_gradient_8j.html#a247f8138ec2ce0f40da15b48331288bf", null ],
    [ "kCGGradientDrawsBeforeStartLocation", "_c_g_gradient_8j.html#aab3edce5c65cc2ed376140c12a398ced", null ]
];