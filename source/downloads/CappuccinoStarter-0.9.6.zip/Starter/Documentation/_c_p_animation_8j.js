var _c_p_animation_8j =
[
    [ "ACTUAL_FRAME_RATE", "_c_p_animation_8j.html#a7b2a03cbc2fda6a7b904233f7acfed30", null ],
    [ "CPAnimationEaseIn", "_c_p_animation_8j.html#af8bd08a7d1a74172de6655f9f79def79", null ],
    [ "CPAnimationEaseInOut", "_c_p_animation_8j.html#a68f342fdaa914b25a2f1938fce3edd96", null ],
    [ "CPAnimationEaseOut", "_c_p_animation_8j.html#afb80342d96f87d9edcd1e1d487a4f5d3", null ],
    [ "CPAnimationLinear", "_c_p_animation_8j.html#a87528b5be07d4fdfb95c940f5cfcc949", null ],
    [ "CubicBezierAtTime", "_c_p_animation_8j.html#a3e7d6de9ccce171225fef8bbf3006cda", null ]
];