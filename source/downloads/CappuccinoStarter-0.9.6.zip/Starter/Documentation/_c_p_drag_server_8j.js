var _c_p_drag_server_8j =
[
    [ "DRAGGING_WINDOW", "_c_p_drag_server_8j.html#aaf11aae455c8ede3a1d09fb24659ab55", null ],
    [ "CPDraggingSource_draggedImage_endedAt_operation_", "_c_p_drag_server_8j.html#a9b5c98d9163fe496ea8ba433e89fcb85", null ],
    [ "CPDraggingSource_draggedImage_movedTo_", "_c_p_drag_server_8j.html#abb59771095856f7cfcbfdc5df700240a", null ],
    [ "CPDraggingSource_draggedView_endedAt_operation_", "_c_p_drag_server_8j.html#a63f642193a69458fc47639256a0cc042", null ],
    [ "CPDraggingSource_draggedView_movedTo_", "_c_p_drag_server_8j.html#af2efd72509109f8895583ae477a8d889", null ],
    [ "CPDragOperationCopy", "_c_p_drag_server_8j.html#a944389d52ade84dda207e764f86e0925", null ],
    [ "CPDragOperationDelete", "_c_p_drag_server_8j.html#ae0f4b1313fe3036efca612af9c2b6f97", null ],
    [ "CPDragOperationEvery", "_c_p_drag_server_8j.html#a2eca1e8e4b86afa0bdbc5cd639941840", null ],
    [ "CPDragOperationGeneric", "_c_p_drag_server_8j.html#afee3fdd674a61c01e44702959ad7dc1b", null ],
    [ "CPDragOperationLink", "_c_p_drag_server_8j.html#af3691c354cfe94bc4bf150e385a36f36", null ],
    [ "CPDragOperationMove", "_c_p_drag_server_8j.html#aea93033cd818a14176498cf7923ba8e5", null ],
    [ "CPDragOperationNone", "_c_p_drag_server_8j.html#a10ed549b8e0424ca530089a1cf12bbd3", null ],
    [ "CPDragOperationPrivate", "_c_p_drag_server_8j.html#adc92d628f356b09262be6fef4545aaae", null ],
    [ "CPDragServerDraggingInfo", "_c_p_drag_server_8j.html#a7a32c9c73ee64e4f82f7aad4ccedc546", null ],
    [ "CPDragServerPeriodicUpdateInterval", "_c_p_drag_server_8j.html#ac179b761d4562d22f9bc9cd9186fae7b", null ],
    [ "CPDragServerPreviousEvent", "_c_p_drag_server_8j.html#a2de78862038eb67a31cc346eb1247738", null ],
    [ "CPDragServerSource", "_c_p_drag_server_8j.html#a3d26048607043fba91d2d880c43c84c0", null ],
    [ "CPSharedDragServer", "_c_p_drag_server_8j.html#af7eb66608c00ee845b021650b8e10210", null ]
];